# File: bdforward.R

### Author:  Andrew M. Ritchie
### Affiliation: Macroevolution and Macroecology, Research School of Biology, ANU
### Email: andrew.ritchie@anu.edu.au

require(ape)
require(mvtnorm)
require(gtools)

bdforward <- function(ntaxa,
                      jump.rate,
                      vcv=matrix(rep(0,4), nrow = 2, ncol = 2),
                      autocorr = rep(T,dim(vcv)[1]),
                      init = rep(0, dim(vcv)[1]),
                      jumpfunc = update.jump,
                      birthfunc = update.birth,
                      deathfunc = update.death,
                      bursts = F,
                      debug = F) 
{
    BURST.MEAN = 0.16
    BURST.SD = 0.054
    
    ntrait <- dim(vcv)[1]

    # Checks
    if(any(dim(vcv)) < 2) stop("Please supply a minimum 2x2 vcv matrix for birth and death.")
    if(dim(vcv)[1]!= dim(vcv)[2]) stop("vcv matrix is not square.")
    if(any(dim(vcv) != length(init)) | any(dim(vcv) != length(autocorr) | length(init) != length(autocorr)
                                           stop("vcv, autocorr and init dimensions do not match".)
    
    # Lineage array: cols are lineages, rows are traits and data
    lineages <- array(0, dim = c(ntrait*2+4,2))
    lineages[,1] <- c(0, 1, jump.rate, init, rep(0,ntrait+1)) # first ancestor, second observed
    lineages[,2] <- c(0, 1, jump.rate, init, rep(0,ntrait+1)) # after values we have cumulatives

    # Labels
    if(!is.null(names(init)))
        {
            trait.nam <- names(init)
            trait.nam[1:2]  <- c("birth", "death")
            trait.nam[trait.nam == ""] <- ifelse(any(trait.nam == "", na.rm=T),
                                                 paste0("trait", 3:(2 + sum(trait.nam == ""))),
                                                 NA)
            ctrait.nam <- paste0("c", trait.nam)
        } else {
            trait.nam <- paste0("trait", 1:length(init))
            trait.nam[1:2] <- c("birth", "death")
            ctrait.nam <- paste0("c", trait.nam)
        }
        
    lin.nam <- c("anc", "obs", "jump", trait.nam, "time", ctrait.nam)
    rownames(lineages) <- lin.nam

    # debug
    if (debug)
    {
        record <- list()
        record <- c(record, c(lineages))
        record.times <- 0
    }

    # SIMULATION LOOP
    repeat
    {

        # Draw waiting time
        rate.mat <- lineages[c("jump", "birth","death"),]
        
        rate.sum <- sum(rate.mat)
        
        event.time <- rexp(1, rate.sum)

        # Accumulate changes since last event
        lineages[(ntrait+4):(ntrait*2+4),] <-
            lineages[(ntrait+4):(ntrait*2+4),] + (event.time * lineages[3:(ntrait+3),])
        
        # Decide what the event is
        event <- sample.int(length(rate.mat), size = 1, prob = rate.mat/rate.sum)

        chosen.one <- (event - 1) %/% dim(rate.mat)[1] + 1
        type <- as.character((event - 1) %% dim(rate.mat)[1] + 1)
        print(paste(c( "JUMP", "BIRTH", "DEATH")[as.integer(type)], chosen.one))

        update <- switch(type,
                         "1" = jumpfunc,
                         "2" = birthfunc,
                         "3" = deathfunc
                         )

        # Make the update
        
        lineages <- update(lineages, chosen.one, vcv, autocorr)        
        
        # Save progress if debugging
        if (debug)
        {
            record <- c(record, c(lineages))
            record.times <- c(record.times, event.time)
        }

        # Break at the specified number of lineages
        N <- sum(lineages["jump",] != 0)
        print (paste(as.character(N), " taxa in tree."))
        if (N >= ntaxa) {
            break
        }
    }
    
    # rescale time
    lineages["time",] <- lineages["time",]/jump.rate

    # make the tree from the lineage array
    tree <- do.prune(construct.tree(lineages, ntrait))
    rownames(tree$anc$data) <- NULL
    if (bursts) tree <- rescale.bursts(tree, BURST.MEAN, BURST.SD)
    
    if (debug)
    {
        tree$record <- record
        tree$times <- record.times
        print(trait.tests)
    }

    return(tree)

}

update.birth <- function(linarray, chosen, ...)
{
    ntrait <- dim(vcv)[1]
    linarray <- cbind(linarray, c(chosen,
                                  1,
                                  linarray[3:(ntrait + 3),chosen],
                                  rep(0, ntrait + 1)
                                  )
                      )
    linarray <- cbind(linarray, c(chosen,
                                  1,
                                  linarray[3:(ntrait + 3),chosen],
                                  rep(0, ntrait + 1)
                                  )
                      )
    linarray[3:(ntrait+3), chosen] <- 0

    return(linarray)
}


update.death <- function(linarray, chosen, ...)
{
    ntrait <- dim(vcv)[1]
    linarray["obs", chosen] <- 0
    linarray[3:(ntrait+3), chosen] <- 0 
    return(linarray)
}

update.jump <- function(linarray, chosen, vcv, autocorr, init, ...)
{
    ntrait <- dim(vcv)[1]
    newmean <- ifelse(autcorr, linarray[4:(ntrait+3), chosen], init)
    linarray[4:(ntrait+3), chosen][autocorr] <- exp(rmvnorm(1,
                                                            mean = newmean,
                                                            sigma = vcv))
    return(linarray)
}

# Rebuild tree from full lineage matrix
construct.tree <- function(linarray, ntrait)
{

    make.br <- function (x,n) 
    {
        br <- read.tree(text = paste0("(", n, ":", as.character(x[ntrait + 4]), ");"))
        br$data <- x
        return(br)
    }

    make.tr <- function(left,right)
    {
        new.tr <- left + right
        if (left$data[1] > 0)
        {
            anc <- linarray[,left$data[1]]
            new.tr$root.edge <- anc[ntrait + 4]
            new.tr$data <- rbind(anc, left$data, right$data)
        } else {
            new.tr$data <- new.tr$data <- rbind(left$data, right$data)
        }
        return(new.tr)
    }

    tips <- linarray[, linarray["obs",] == 0  | linarray["jump",] != 0] 
    ntip <- dim(tips)[2]
       
    tip.br <- sapply(1:ntip, 
                     function (x) make.br(tips[,x], as.character(x)),
                     simplify = F
    )

    while(length(tip.br) > 1)
    {

        ancs <- sapply(tip.br, function(x) x$data[1])
        print(length(tip.br))
        print(ancs)
        
        # Join subtrees with the same ancestor
        cherry.arr <- outer(ancs, ancs, FUN = "==") & upper.tri(diag(length(ancs)))
        cherries <- which(cherry.arr == TRUE, arr.ind = T)
        cherry.trees <- apply(cherries,
                              1,
                              function(x) make.tr(tip.br[[x[1]]], tip.br[[x[2]]])
                              )
        tip.br <- c(cherry.trees, tip.br[-as.vector(cherries)])
        
    }

    print(length(tip.br))
    
    return(tip.br[1])
}

# Prune sleeping taxa
do.prune <- function (tree)
{
    tip.depth <- node.depth.edgelength(tree)[1:Ntip(tree)]
    dropped <- which(tip.depth < max(tip.depth))
    np <- nodepath(tree)
    dropped.node <- apply(tree$edge,1,setdiff(unlist(np[dropped]), unlist(np[-dropped]))
    rec.tree <- drop.tip(tree, dropped)
    rec.tree$data <- tree$data[-apply(tree$edge,1, function (x) any(is.element(x), dropped.node)),]
    
    return (rec.tree)
}

# Add bursts to nodes
rescale.bursts <- function (tree, bltrait, burst.mean, burst.sd)
{
    brlens <- tree$data[,bltrait]
    trlen <- sum(brlen)
    trlen.burst <- exp(rlnorm(1, log(trlen/(1 - burst.mean)), sdlog = log(trlen/(1 - burst.sd))))
    newblens <- (brlens + (dirichlet(1, rep(1, Nedge(tree)))) * trlen.burst)) * (trlen/trlen.burst)
    tree$data[,bltrait] <- newblens

    return (tree)
}

bdforward.sample.gsa <- function (treelist, ntaxa, ntrait, sampling.frac = 1, prune = T)
{
    VAL.IDX <- 4
    indices <- c(VAL = VAL.IDX,
                 ACC = VAL.IDX + ntrait,
                 TIME = VAL.IDX + ntrait * 2,
                 END = VAL.IDX + ntrait * 2 + 1
                 )
    
    k <- 0
    periods <- list()
    sumtimes <- 0
    timeoverall <- list()
    for (j in treelist)
    {
        if (is.phylo(j))
        {
            k <- k + 1
            periods[[k]] <- get.periods(j) %>% filter(number == ntaxa)
            timeoverall[[k]] <- periods[[k]] %>% pull(duration) %>% sum
            sumtimes <- sumtimes + timeoverall[[k]]
        }
    }

    average.time <- sumtimes/(k * sampling.frac)

    treelist.out <- list()
    k <- 0
    for (j in treelist)
    {
        if (is.phylo(j))
        {
            k <- k + 1
            sample.thresh <- timeoverall[[k]]/average.time
            if (runif(1, 0, 1) < sample.thresh)
            {
                cut.period <- periods[[k]]$period[sample.int(dim(periods[[k]])[1],
                                                             1,
                                                             prob=periods[[k]]$duration)
                                                  ]
                cut.interval <- periods[[k]] %>% filter(period == cut.period) %>% select(start.t, end.t)
                cuttime <- runif(1, cut.interval$start.t, cut.interval$end.t)
                treelist.out[[k]] <- slicetree.with.data(j, cuttime, indices)
                if (prune) treelist.out[[k]] <- prune.with.data(treelist.out[[k]], indices)
                               
                message(paste("Tree", k, "sampled at time", cuttime))
            }
        }
    }

    treelist.out <- treelist.out[!sapply(treelist.out, is.null)]
    
    return(treelist.out)        

}

# EOF
